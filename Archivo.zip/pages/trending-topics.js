import React from 'react'
import "../public/styles.scss"

const Trending = () => {
  return(
    <>
      <img src="/static/img/under.gif" alt=""/>
    </>
  )
}
export default Trending
